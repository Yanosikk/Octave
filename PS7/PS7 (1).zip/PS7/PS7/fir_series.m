function b = fir_series(b1, b2)
b = sig_conv(b2, b1);
endfunction
